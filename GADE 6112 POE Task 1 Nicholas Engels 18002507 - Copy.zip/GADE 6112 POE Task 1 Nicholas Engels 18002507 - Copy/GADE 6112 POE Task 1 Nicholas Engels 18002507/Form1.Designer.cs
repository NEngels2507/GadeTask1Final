﻿namespace GADE_6112_POE_Task_1_Nicholas_Engels_18002507
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtTurn = new System.Windows.Forms.TextBox();
            this.Start1 = new System.Windows.Forms.Button();
            this.Stop1 = new System.Windows.Forms.Button();
            this.txt = new System.Windows.Forms.TextBox();
            this.SaveBTN = new System.Windows.Forms.Button();
            this.ReadBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(649, 582);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // txtTurn
            // 
            this.txtTurn.Location = new System.Drawing.Point(718, 26);
            this.txtTurn.Name = "txtTurn";
            this.txtTurn.Size = new System.Drawing.Size(100, 22);
            this.txtTurn.TabIndex = 1;
            // 
            // Start1
            // 
            this.Start1.Location = new System.Drawing.Point(718, 64);
            this.Start1.Name = "Start1";
            this.Start1.Size = new System.Drawing.Size(75, 23);
            this.Start1.TabIndex = 2;
            this.Start1.Text = "Start";
            this.Start1.UseVisualStyleBackColor = true;
            this.Start1.Click += new System.EventHandler(this.Start1_Click);
            // 
            // Stop1
            // 
            this.Stop1.Location = new System.Drawing.Point(718, 104);
            this.Stop1.Name = "Stop1";
            this.Stop1.Size = new System.Drawing.Size(75, 23);
            this.Stop1.TabIndex = 3;
            this.Stop1.Text = "Stop";
            this.Stop1.UseVisualStyleBackColor = true;
            this.Stop1.Click += new System.EventHandler(this.Stop1_Click);
            // 
            // txt
            // 
            this.txt.Location = new System.Drawing.Point(718, 145);
            this.txt.Multiline = true;
            this.txt.Name = "txt";
            this.txt.Size = new System.Drawing.Size(154, 199);
            this.txt.TabIndex = 4;
            // 
            // SaveBTN
            // 
            this.SaveBTN.Location = new System.Drawing.Point(718, 364);
            this.SaveBTN.Name = "SaveBTN";
            this.SaveBTN.Size = new System.Drawing.Size(75, 23);
            this.SaveBTN.TabIndex = 5;
            this.SaveBTN.Text = "Save";
            this.SaveBTN.UseVisualStyleBackColor = true;
            this.SaveBTN.Click += new System.EventHandler(this.SaveBTN_Click);
            // 
            // ReadBTN
            // 
            this.ReadBTN.Location = new System.Drawing.Point(718, 394);
            this.ReadBTN.Name = "ReadBTN";
            this.ReadBTN.Size = new System.Drawing.Size(75, 23);
            this.ReadBTN.TabIndex = 6;
            this.ReadBTN.Text = "Read";
            this.ReadBTN.UseVisualStyleBackColor = true;
            this.ReadBTN.Click += new System.EventHandler(this.ReadBTN_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(904, 707);
            this.Controls.Add(this.ReadBTN);
            this.Controls.Add(this.SaveBTN);
            this.Controls.Add(this.txt);
            this.Controls.Add(this.Stop1);
            this.Controls.Add(this.Start1);
            this.Controls.Add(this.txtTurn);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtTurn;
        private System.Windows.Forms.Button Start1;
        private System.Windows.Forms.Button Stop1;
        private System.Windows.Forms.TextBox txt;
        private System.Windows.Forms.Button SaveBTN;
        private System.Windows.Forms.Button ReadBTN;
    }
}

